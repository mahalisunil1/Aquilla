const mongoose = require('mongoose');

const propertySchema = new mongoose.Schema({
    propertyId: String,
    publishedOn: Date,
    publishedBy: String,
    publisherEmailId: String,
    postedBy: String,
    hasAdminAttended: Boolean,
    approvalStatus: String,
    propertyDetails: Object,
    formConfig: Object
  });

Property = mongoose.model('Property', propertySchema);

module.exports = Property